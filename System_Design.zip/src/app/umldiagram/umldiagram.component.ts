import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-umldiagram',
  templateUrl: './umldiagram.component.html',
  styleUrls: ['./umldiagram.component.css']
})
export class UmldiagramComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
